// generate-posts.js
// 「会社の裏設定」ネタ元から、毎日のThreads投稿案を自動生成してDiscordに通知するスクリプト。
// このバージョン(フェーズ1)は「案の生成のみ」。実際の投稿は人間が選んで手動で行う。

const fs = require("fs");
const path = require("path");

const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY;
const DISCORD_WEBHOOK_URL = process.env.DISCORD_WEBHOOK_URL;
const POSTS_PER_DAY = parseInt(process.env.POSTS_PER_DAY || "3", 10);

const THEMES_PATH = path.join(__dirname, "themes.json");
const STATE_PATH = path.join(__dirname, "state", "used-themes.json");
// 反応データ(フェーズ3で日次記録される想定)。無ければ空配列として扱う。
const PERFORMANCE_PATH = path.join(__dirname, "state", "performance.json");

// 投稿の「型」。毎回同じ構成にならないよう、生成のたびにランダムで選ぶ。
// (直近で使った型は state 側で除外するので、連日同じ型が続きにくい)
const POST_PATTERNS = [
  {
    name: "告白型",
    instruction:
      "「正直〜」「実は〜」など、本音をこっそり打ち明けるようなトーンで書き出す。",
  },
  {
    name: "問いかけ型",
    instruction:
      "読者に直接問いかける一文から始める(「〜だと思いませんか」「〜したこと、ありませんか」など)。答えは急がず、共感してから展開する。",
  },
  {
    name: "ビフォーアフター型",
    instruction:
      "「昔は〜だと思っていた。でも管理職になって〜だと分かった」という、自分の中の変化を軸に書く。",
  },
  {
    name: "セリフ再現型",
    instruction:
      "部下や上司から実際に言われた一言をカギカッコで冒頭に置き、その場面から話を展開する。",
  },
  {
    name: "毒舌型",
    instruction:
      "冒頭であえて厳しめの本音・皮肉を一言だけ置く(例:「優しい上司ほど、実は部下を潰す」)。ただし攻撃的になりすぎないよう、そのあとの展開と着地は必ず前向きにする。多用すると嫌味に見えるので、鋭さは一箇所だけに留める。",
  },
  {
    name: "数字型",
    instruction:
      "件数・年数・回数など具体的な数字を冒頭に置き、意外性で興味を引く(例:「161本書いて気づいたのは〜」)。",
  },
  {
    name: "対比型",
    instruction:
      "「Aだと思われがちだが、実際はBだ」という一見意外な対比を最初に提示し、そのギャップを埋める形で書く。",
  },
];

function loadJson(filePath, fallback) {
  if (!fs.existsSync(filePath)) return fallback;
  return JSON.parse(fs.readFileSync(filePath, "utf-8"));
}

function pickThemes(themes, usedIds, count) {
  // 未使用のテーマを優先。全部使い切ったら使用済みリストをリセットして再利用する。
  let candidates = themes.filter((t) => !usedIds.includes(t.id));
  if (candidates.length < count) {
    usedIds = [];
    candidates = themes;
  }
  // シャッフルして先頭からcount件取る
  const shuffled = [...candidates].sort(() => Math.random() - 0.5);
  return { picked: shuffled.slice(0, count), usedIds };
}

// 直近で使った型を避けつつ、count件ぶんの型を重複なく選ぶ(同じバッチ内でもパターンが揃うのを防ぐ)。
// 候補が足りなくなったら、直近除外リストを無視して全パターンから補充する。
function pickPatterns(recentPatternNames, count) {
  let pool = POST_PATTERNS.filter((p) => !recentPatternNames.includes(p.name));
  if (pool.length < count) pool = POST_PATTERNS.slice();

  const shuffled = [...pool].sort(() => Math.random() - 0.5);
  const picked = [];
  for (let i = 0; i < count; i++) {
    picked.push(shuffled[i % shuffled.length]);
  }
  return picked;
}

function buildPerformanceSummary(performance) {
  if (!performance || performance.length === 0) {
    return "(まだ反応データがありません。通常の判断で作成してください)";
  }
  // 直近の反応が良かった投稿・悪かった投稿を上位/下位3件ずつ要約してプロンプトに渡す
  const sorted = [...performance].sort((a, b) => (b.engagement || 0) - (a.engagement || 0));
  const top = sorted.slice(0, 3);
  const bottom = sorted.slice(-3);
  const fmt = (p) => `・「${p.title}」(反応スコア:${p.engagement}) 傾向メモ: ${p.note || "なし"}`;
  return [
    "【直近で反応が良かった投稿】",
    ...top.map(fmt),
    "【直近で反応が悪かった投稿】",
    ...bottom.map(fmt),
  ].join("\n");
}

async function generatePostDraft(theme, pattern, performanceSummary) {
  const prompt = `あなたは製造業の管理職向けに発信しているThreadsアカウント「PocketHappy」の投稿作成アシスタントです。
以下のネタ元を基に、Threads投稿文を1本作成してください。

【ネタ元】
タイトル: ${theme.title}
テーマ: ${theme.theme}
教訓: ${theme.lesson}
キーワード: ${theme.keywords.join("、")}

【過去の反応データ(参考にして書き方を調整すること)】
${performanceSummary}

【今回使う構成の型: ${pattern.name}】
${pattern.instruction}

【文章の質に関する条件】
- Threadsなので日本語で300文字以内
- 一文を短く区切り、体言止めや言い切りも交ぜて、AIが書いたような滑らかすぎる文章にしない
- 抽象論で終わらせず、具体的な場面・数字・セリフを入れる
- 上から目線の説教にならないよう共感ベースで書く。予定調和になりすぎないよう、最初か途中に一言だけ本音・皮肉を混ぜてもよい(毒を出しすぎて攻撃的にならないよう、着地は必ず前向きにする)
- 読んだ人が「あるある、わかる」と思うか、「え、そうなの」と驚くかのどちらかを狙う
- 最後の締めくくり方(問いかけ/一言アドバイス/宣言/余韻を残す、など)は指定しないので、その投稿に合う形を自分で選ぶ(毎回同じ締め方にしない)
- ハッシュタグは付けない
- Markdown記号(#や*など)は使わない

投稿文だけを出力してください。前置きや説明は不要です。`;

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 500,
      messages: [{ role: "user", content: prompt }],
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Claude API error: ${response.status} ${errText}`);
  }

  const data = await response.json();
  const textBlock = data.content.find((c) => c.type === "text");
  return textBlock ? textBlock.text.trim() : "(生成失敗)";
}

async function postToDiscord(drafts) {
  if (!DISCORD_WEBHOOK_URL) {
    console.log("DISCORD_WEBHOOK_URL未設定のため、Discord通知はスキップします。");
    return;
  }

  const lines = drafts.map((d, i) => {
    return `**${i + 1}. 元ネタ: ${d.theme.title}(型: ${d.pattern.name})**\n${d.text}\n`;
  });

  const content = [
    `📝 本日のThreads投稿案 (${drafts.length}件)`,
    "",
    ...lines,
    "気に入ったものを選んで手動で投稿してください。",
  ].join("\n");

  // Discordの2000文字制限に配慮して分割送信
  const chunks = [];
  let current = "";
  for (const line of content.split("\n")) {
    if ((current + line).length > 1800) {
      chunks.push(current);
      current = "";
    }
    current += line + "\n";
  }
  if (current) chunks.push(current);

  for (const chunk of chunks) {
    await fetch(DISCORD_WEBHOOK_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content: chunk }),
    });
  }
}

async function main() {
  if (!ANTHROPIC_API_KEY) {
    throw new Error("ANTHROPIC_API_KEY が設定されていません。");
  }

  const themes = loadJson(THEMES_PATH, []);
  if (themes.length === 0) {
    throw new Error("themes.json にネタがありません。");
  }

  const state = loadJson(STATE_PATH, { used_ids: [], recent_patterns: [] });
  const performance = loadJson(PERFORMANCE_PATH, []);

  const { picked, usedIds } = pickThemes(themes, state.used_ids, POSTS_PER_DAY);
  const patterns = pickPatterns(state.recent_patterns || [], POSTS_PER_DAY);
  const performanceSummary = buildPerformanceSummary(performance);

  const drafts = [];
  for (let i = 0; i < picked.length; i++) {
    const theme = picked[i];
    const pattern = patterns[i];
    console.log(`生成中: ${theme.title}(型: ${pattern.name})`);
    const text = await generatePostDraft(theme, pattern, performanceSummary);
    drafts.push({ theme, pattern, text });
  }

  await postToDiscord(drafts);

  // 使用済みテーマ・直近使用パターンを記録(直近使用パターンは次回以降に避けるため、
  // 今回使った分だけを残す。全件残すと候補が枯渇するので直近1バッチぶんのみ保持)
  const newUsedIds = [...usedIds, ...picked.map((t) => t.id)];
  const newRecentPatterns = patterns.map((p) => p.name);
  fs.writeFileSync(
    STATE_PATH,
    JSON.stringify({ used_ids: newUsedIds, recent_patterns: newRecentPatterns }, null, 2)
  );

  // ログ出力(GitHub Actionsのartifact/確認用)
  const logPath = path.join(__dirname, "state", `generated-${new Date().toISOString().slice(0, 10)}.json`);
  fs.writeFileSync(logPath, JSON.stringify(drafts, null, 2), "utf-8");

  console.log(`${drafts.length}件の投稿案を生成しました。`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
